## 提交材料内容

**项目开发文档: **	 1. 软件需求规格说明(SRS).doc         2. 软件(结构)设计说明(SDD).doc

​                                 3. 项目开发总结报告(PDSR).doc      4. 软件产品规格说明(SPS).doc

**项目开发代码:**         project.zip

**项目展示PPT:**         学生健康信息平台展示.pptx

**github地址:**           https://github.com/a123wyn/Student-information-reporting-system